#include "pch.h"
#include "CustomEquipIdState.h"

#include <Windows.h>

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "log.h"

namespace
{
    constexpr std::int32_t kMinimumPersistentEquipId = 1;
    constexpr int kSaveFileVersion = 2;
    constexpr const char* kSaveFileRelativePath = "mod\\saves\\V_FrameWork_CustomEquipIds.lua";

    std::mutex g_CustomEquipIdStateMutex;
    std::once_flag g_LoadOnce;

    std::unordered_map<std::string, std::int32_t> g_PersistedEquipIdsByKey;
    std::unordered_set<std::int32_t> g_ReservedEquipIds;

    static std::string GetModuleDirectory()
    {
        char modulePath[MAX_PATH] = {};
        const DWORD len = GetModuleFileNameA(nullptr, modulePath, MAX_PATH);
        if (len == 0 || len >= MAX_PATH)
            return std::string();

        std::string path(modulePath, len);
        const std::size_t slash = path.find_last_of("\\/");
        if (slash == std::string::npos)
            return std::string();

        return path.substr(0, slash);
    }

    static std::string JoinPath(const std::string& left, const std::string& right)
    {
        if (left.empty())
            return right;

        if (right.empty())
            return left;

        const char last = left[left.size() - 1];
        if (last == '\\' || last == '/')
            return left + right;

        return left + "\\" + right;
    }

    static std::string GetSaveFilePath()
    {
        const std::string moduleDir = GetModuleDirectory();
        if (moduleDir.empty())
            return std::string();

        return JoinPath(moduleDir, kSaveFileRelativePath);
    }

    static bool DirectoryExists(const std::string& path)
    {
        const DWORD attr = GetFileAttributesA(path.c_str());
        return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) != 0;
    }

    static bool FileExists(const std::string& path)
    {
        const DWORD attr = GetFileAttributesA(path.c_str());
        return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0;
    }

    static bool EnsureDirectoryExistsSingle(const std::string& path)
    {
        if (path.empty())
            return false;

        if (DirectoryExists(path))
            return true;

        if (CreateDirectoryA(path.c_str(), nullptr) != 0)
            return true;

        const DWORD err = GetLastError();
        return err == ERROR_ALREADY_EXISTS && DirectoryExists(path);
    }

    static bool EnsureSaveDirectoryExists()
    {
        const std::string moduleDir = GetModuleDirectory();
        if (moduleDir.empty())
            return false;

        const std::string modDir = JoinPath(moduleDir, "mod");
        const std::string savesDir = JoinPath(modDir, "saves");

        if (!EnsureDirectoryExistsSingle(modDir))
        {
            Log("[CustomEquipIdState] Failed to create mod directory: %s\n", modDir.c_str());
            return false;
        }

        if (!EnsureDirectoryExistsSingle(savesDir))
        {
            Log("[CustomEquipIdState] Failed to create saves directory: %s\n", savesDir.c_str());
            return false;
        }

        return true;
    }

    static std::string EscapeLuaString(const std::string& value)
    {
        std::string out;
        out.reserve(value.size());

        for (std::size_t i = 0; i < value.size(); ++i)
        {
            const char c = value[i];
            switch (c)
            {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:   out += c; break;
            }
        }

        return out;
    }

    static bool ParseIntLiteral(const std::string& text, std::int32_t& outValue)
    {
        try
        {
            std::size_t consumed = 0;
            long long value = 0;

            if (text.size() > 2 && text[0] == '0' && (text[1] == 'x' || text[1] == 'X'))
                value = std::stoll(text, &consumed, 16);
            else
                value = std::stoll(text, &consumed, 10);

            if (consumed != text.size())
                return false;

            outValue = static_cast<std::int32_t>(value);
            return true;
        }
        catch (...)
        {
            return false;
        }
    }

    static std::int32_t NormalizeMinimumEquipId(std::int32_t minimumEquipId)
    {
        if (minimumEquipId < kMinimumPersistentEquipId)
            return kMinimumPersistentEquipId;

        return minimumEquipId;
    }

    static std::int32_t FindNextFreeEquipIdUnlocked(std::int32_t minimumEquipId)
    {
        std::int32_t candidate = NormalizeMinimumEquipId(minimumEquipId);

        while (g_ReservedEquipIds.find(candidate) != g_ReservedEquipIds.end())
            ++candidate;

        return candidate;
    }

    static bool SaveUnlocked()
    {
        if (!EnsureSaveDirectoryExists())
            return false;

        const std::string savePath = GetSaveFilePath();
        if (savePath.empty())
            return false;

        std::vector<std::pair<std::string, std::int32_t> > sortedEntries;
        sortedEntries.reserve(g_PersistedEquipIdsByKey.size());

        for (std::unordered_map<std::string, std::int32_t>::const_iterator it = g_PersistedEquipIdsByKey.begin();
            it != g_PersistedEquipIdsByKey.end();
            ++it)
        {
            sortedEntries.push_back(*it);
        }

        std::sort(
            sortedEntries.begin(),
            sortedEntries.end(),
            [](const std::pair<std::string, std::int32_t>& a, const std::pair<std::string, std::int32_t>& b)
            {
                return a.first < b.first;
            });

        std::ostringstream out;
        out << "return {\n";
        out << "    version = " << kSaveFileVersion << ",\n";
        out << "    guns = {\n";

        for (std::size_t i = 0; i < sortedEntries.size(); ++i)
        {
            out << "        [\"" << EscapeLuaString(sortedEntries[i].first) << "\"] = 0x"
                << std::uppercase << std::hex << sortedEntries[i].second << std::dec << std::nouppercase
                << ",\n";
        }

        out << "    }\n";
        out << "}\n";

        std::ofstream file(savePath.c_str(), std::ios::binary | std::ios::trunc);
        if (!file.is_open())
        {
            Log("[CustomEquipIdState] Failed to open save file for writing: %s\n", savePath.c_str());
            return false;
        }

        const std::string text = out.str();
        file.write(text.data(), static_cast<std::streamsize>(text.size()));
        file.close();

        Log("[CustomEquipIdState] Saved %zu equip id mappings to %s\n",
            g_PersistedEquipIdsByKey.size(),
            savePath.c_str());

        return true;
    }

    static std::size_t SkipWhitespace(const std::string& text, std::size_t pos)
    {
        while (pos < text.size())
        {
            const char c = text[pos];
            if (c != ' ' && c != '\t' && c != '\r' && c != '\n')
                break;
            ++pos;
        }

        return pos;
    }

    static bool ReadLuaQuotedString(const std::string& text, std::size_t startQuote, std::string& outValue, std::size_t& outNextPos)
    {
        outValue.clear();
        outNextPos = startQuote;

        if (startQuote >= text.size() || text[startQuote] != '"')
            return false;

        std::size_t pos = startQuote + 1;
        while (pos < text.size())
        {
            const char c = text[pos];
            if (c == '\\')
            {
                if (pos + 1 >= text.size())
                    return false;

                const char next = text[pos + 1];
                switch (next)
                {
                case '\\': outValue.push_back('\\'); break;
                case '"':  outValue.push_back('"'); break;
                case 'n':  outValue.push_back('\n'); break;
                case 'r':  outValue.push_back('\r'); break;
                case 't':  outValue.push_back('\t'); break;
                default:   outValue.push_back(next); break;
                }

                pos += 2;
                continue;
            }

            if (c == '"')
            {
                outNextPos = pos + 1;
                return true;
            }

            outValue.push_back(c);
            ++pos;
        }

        return false;
    }

    static bool ReadLuaNumberToken(const std::string& text, std::size_t pos, std::string& outToken, std::size_t& outNextPos)
    {
        outToken.clear();
        outNextPos = pos;

        pos = SkipWhitespace(text, pos);
        if (pos >= text.size())
            return false;

        const std::size_t begin = pos;

        if (text[pos] == '+' || text[pos] == '-')
            ++pos;

        if (pos + 1 < text.size() && text[pos] == '0' && (text[pos + 1] == 'x' || text[pos + 1] == 'X'))
        {
            pos += 2;
            const std::size_t hexBegin = pos;
            while (pos < text.size())
            {
                const char c = text[pos];
                const bool isHex =
                    (c >= '0' && c <= '9') ||
                    (c >= 'a' && c <= 'f') ||
                    (c >= 'A' && c <= 'F');
                if (!isHex)
                    break;
                ++pos;
            }

            if (pos == hexBegin)
                return false;
        }
        else
        {
            const std::size_t decBegin = pos;
            while (pos < text.size() && text[pos] >= '0' && text[pos] <= '9')
                ++pos;

            if (pos == decBegin)
                return false;
        }

        outToken = text.substr(begin, pos - begin);
        outNextPos = pos;
        return true;
    }

    static void LoadUnlocked()
    {
        g_PersistedEquipIdsByKey.clear();
        g_ReservedEquipIds.clear();

        const std::string savePath = GetSaveFilePath();
        if (savePath.empty())
        {
            Log("[CustomEquipIdState] Failed to resolve save path\n");
            return;
        }

        if (!FileExists(savePath))
        {
            Log("[CustomEquipIdState] Save file does not exist yet: %s\n", savePath.c_str());
            return;
        }

        std::ifstream file(savePath.c_str(), std::ios::binary);
        if (!file.is_open())
        {
            Log("[CustomEquipIdState] Failed to open save file: %s\n", savePath.c_str());
            return;
        }

        std::ostringstream buffer;
        buffer << file.rdbuf();
        const std::string text = buffer.str();

        bool dirty = false;
        std::size_t pos = 0;

        while (true)
        {
            pos = text.find('[', pos);
            if (pos == std::string::npos)
                break;

            std::size_t cursor = SkipWhitespace(text, pos + 1);
            if (cursor >= text.size() || text[cursor] != '"')
            {
                ++pos;
                continue;
            }

            std::string gunKey;
            std::size_t afterKey = 0;
            if (!ReadLuaQuotedString(text, cursor, gunKey, afterKey))
            {
                ++pos;
                continue;
            }

            cursor = SkipWhitespace(text, afterKey);
            if (cursor >= text.size() || text[cursor] != ']')
            {
                ++pos;
                continue;
            }

            cursor = SkipWhitespace(text, cursor + 1);
            if (cursor >= text.size() || text[cursor] != '=')
            {
                ++pos;
                continue;
            }

            ++cursor;

            std::string idToken;
            std::size_t afterValue = 0;
            if (!ReadLuaNumberToken(text, cursor, idToken, afterValue))
            {
                ++pos;
                continue;
            }

            if (gunKey.empty())
            {
                pos = afterValue;
                continue;
            }

            std::int32_t equipId = 0;
            if (!ParseIntLiteral(idToken, equipId))
            {
                Log("[CustomEquipIdState] Failed to parse equipId for key %s\n", gunKey.c_str());
                pos = afterValue;
                continue;
            }

            if (g_PersistedEquipIdsByKey.find(gunKey) != g_PersistedEquipIdsByKey.end())
            {
                Log("[CustomEquipIdState] Duplicate gun key in save file, keeping first: %s\n", gunKey.c_str());
                dirty = true;
                pos = afterValue;
                continue;
            }

            if (equipId < kMinimumPersistentEquipId || g_ReservedEquipIds.find(equipId) != g_ReservedEquipIds.end())
            {
                const std::int32_t repairedId = FindNextFreeEquipIdUnlocked(kMinimumPersistentEquipId);

                g_PersistedEquipIdsByKey[gunKey] = repairedId;
                g_ReservedEquipIds.insert(repairedId);

                Log("[CustomEquipIdState] Repaired mapping %s -> 0x%X while loading\n", gunKey.c_str(), repairedId);
                dirty = true;
                pos = afterValue;
                continue;
            }

            g_PersistedEquipIdsByKey[gunKey] = equipId;
            g_ReservedEquipIds.insert(equipId);
            pos = afterValue;
        }

        Log("[CustomEquipIdState] Loaded %zu equip id mappings\n", g_PersistedEquipIdsByKey.size());

        if (dirty)
            SaveUnlocked();
    }

    static void EnsureLoaded()
    {
        std::call_once(
            g_LoadOnce,
            []()
            {
                std::lock_guard<std::mutex> lock(g_CustomEquipIdStateMutex);
                LoadUnlocked();
            });
    }
}

namespace CustomEquipIdState
{
    bool ResolveOrCreatePersistentEquipId(const char* gunKey, std::int32_t minimumEquipId, std::int32_t& outEquipId)
    {
        outEquipId = 0;

        if (!gunKey || !gunKey[0])
            return false;

        EnsureLoaded();

        std::lock_guard<std::mutex> lock(g_CustomEquipIdStateMutex);

        minimumEquipId = NormalizeMinimumEquipId(minimumEquipId);

        std::unordered_map<std::string, std::int32_t>::iterator found = g_PersistedEquipIdsByKey.find(gunKey);
        if (found != g_PersistedEquipIdsByKey.end())
        {
            if (found->second < minimumEquipId)
            {
                g_ReservedEquipIds.erase(found->second);

                const std::int32_t repairedId = FindNextFreeEquipIdUnlocked(minimumEquipId);
                found->second = repairedId;
                g_ReservedEquipIds.insert(repairedId);
                outEquipId = repairedId;

                Log("[CustomEquipIdState] Migrated mapping %s -> 0x%X\n", gunKey, repairedId);
                SaveUnlocked();
                return true;
            }

            outEquipId = found->second;
            return true;
        }

        const std::int32_t newEquipId = FindNextFreeEquipIdUnlocked(minimumEquipId);

        g_PersistedEquipIdsByKey[gunKey] = newEquipId;
        g_ReservedEquipIds.insert(newEquipId);
        outEquipId = newEquipId;

        Log("[CustomEquipIdState] Created mapping %s -> 0x%X\n", gunKey, newEquipId);

        SaveUnlocked();
        return true;
    }

    bool TryGetPersistentEquipId(const char* gunKey, std::int32_t& outEquipId)
    {
        outEquipId = 0;

        if (!gunKey || !gunKey[0])
            return false;

        EnsureLoaded();

        std::lock_guard<std::mutex> lock(g_CustomEquipIdStateMutex);

        std::unordered_map<std::string, std::int32_t>::const_iterator found = g_PersistedEquipIdsByKey.find(gunKey);
        if (found == g_PersistedEquipIdsByKey.end())
            return false;

        outEquipId = found->second;
        return true;
    }

    bool SaveNow()
    {
        EnsureLoaded();

        std::lock_guard<std::mutex> lock(g_CustomEquipIdStateMutex);
        return SaveUnlocked();
    }

    void ClearAllPersistentEquipIds()
    {
        EnsureLoaded();

        std::lock_guard<std::mutex> lock(g_CustomEquipIdStateMutex);

        g_PersistedEquipIdsByKey.clear();
        g_ReservedEquipIds.clear();

        SaveUnlocked();
        Log("[CustomEquipIdState] Cleared all persistent equip ids\n");
    }
}
