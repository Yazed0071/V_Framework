#include "pch.h"
#include "DeclareWPs.h"

#include <Windows.h>
#include <cstdint>
#include <mutex>
#include <string>
#include <unordered_map>

#include "log.h"

namespace
{
    constexpr int LUA_GLOBALSINDEX_51 = -10002;
    constexpr int LUA_TTABLE_51 = 5;

    DeclareWPs::Deps g_Deps{};

    std::mutex g_DeclareWPsMutex;
    std::unordered_map<std::string, std::uint32_t> g_DeclaredWPs;

    // Custom WP ids start after the stock DeclareWPs range.
    std::uint32_t g_NextCustomWpId = 0x203;
}

namespace
{
    static bool ValidateDeps()
    {
        return
            g_Deps.ResolveLuaApi &&
            g_Deps.GetLuaTop &&
            g_Deps.LuaGetField &&
            g_Deps.LuaType &&
            g_Deps.LuaPop &&
            g_Deps.GetLuaString &&
            g_Deps.PushLuaNumber &&
            g_Deps.LuaPushString &&
            g_Deps.LuaCreateTable &&
            g_Deps.LuaRawSet &&
            g_Deps.LuaSetTable;
    }

    static bool EnsureTppEquipTable(lua_State* L)
    {
        g_Deps.LuaGetField(L, LUA_GLOBALSINDEX_51, "TppEquip");
        if (g_Deps.LuaType(L, -1) == LUA_TTABLE_51)
            return true;

        g_Deps.LuaPop(L, 1);

        g_Deps.LuaPushString(L, "TppEquip");
        g_Deps.LuaCreateTable(L, 0, 0);
        g_Deps.LuaRawSet(L, LUA_GLOBALSINDEX_51);

        g_Deps.LuaGetField(L, LUA_GLOBALSINDEX_51, "TppEquip");
        return g_Deps.LuaType(L, -1) == LUA_TTABLE_51;
    }

    static void DeclareWpInLua(lua_State* L, const char* name, std::uint32_t wpId)
    {
        if (!EnsureTppEquipTable(L))
            return;

        // stack top is TppEquip
        g_Deps.LuaPushString(L, name);
        g_Deps.PushLuaNumber(L, static_cast<float>(wpId));
        g_Deps.LuaSetTable(L, -3);

        // pop TppEquip
        g_Deps.LuaPop(L, 1);
    }
}

namespace DeclareWPs
{
    void Bind(const Deps& deps)
    {
        g_Deps = deps;
    }

    int __cdecl Lua_DeclareWPs(lua_State* L)
    {
        if (!L || !ValidateDeps() || !g_Deps.ResolveLuaApi || !g_Deps.ResolveLuaApi())
        {
            if (g_Deps.PushLuaNumber)
                g_Deps.PushLuaNumber(L, 0.0f);
            return 1;
        }

        const char* name = g_Deps.GetLuaString(L, 1);
        if (!name || !name[0])
        {
            g_Deps.PushLuaNumber(L, 0.0f);
            return 1;
        }

        std::uint32_t wpId = 0;

        {
            std::lock_guard<std::mutex> lock(g_DeclareWPsMutex);

            const auto it = g_DeclaredWPs.find(name);
            if (it != g_DeclaredWPs.end())
            {
                wpId = it->second;
            }
            else
            {
                wpId = g_NextCustomWpId++;
                g_DeclaredWPs.emplace(name, wpId);

                Log("[DeclareWPs] Added custom WP '%s' => 0x%X (%u)\n",
                    name, wpId, wpId);
            }
        }

        DeclareWpInLua(L, name, wpId);
        g_Deps.PushLuaNumber(L, static_cast<float>(wpId));
        return 1;
    }
}